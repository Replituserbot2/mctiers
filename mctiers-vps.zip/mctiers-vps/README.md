# mctiers-vps

Self-hosted mirror of mctiers.net reconstructed from a HAR capture.
Runs a pure Node.js (no npm deps) HTTP server.

## Requirements

- Node.js 18+
- A VPS / any machine that can open a port

## Run

```bash
node server.js
# or
PORT=8080 node server.js
```

## What works

- `/rankings/overall` — full rankings page with all 40 players
- `/rankings/:mode` — mode tab switching (client-side, served from same HTML)
- `/_next/static/**` — all JS chunks and CSS captured from the live site
- `/api/v2/mode/list` — mode list
- `/api/v2/mode/overall?from=0&count=10` — paginated overall rankings
- `/api/v2/mode/:mode?from=0&count=10` — per-mode rankings (derived from overall data)
- `/api/v2/player/:name` — player lookup by name
- All assets: tier icons, placement shimmer SVGs, nav icons, title badges, fonts

## Known bugs / limitations

1. **Only 40 players captured.** The HAR only scrolled through 4 pages (40 entries).
   Per-mode lists are derived from these 40; lower-tier players are missing.

2. **3D bust images load from render.crafty.gg** (external CDN). They work as
   long as that CDN is up; no offline fallback.

3. **`a6dad97d9634a72d.js` is missing** — it's the `nomodule` IE11 polyfill
   referenced in the HTML. Modern browsers skip it; safe to ignore.

4. **Search functionality** — the player search in the nav fires a live
   `/api/v2/player/` lookup. Only returns players in the 40-player dataset.

5. **Docs pages (`/docs/v2`)** — render partially. The docs were a heavy
   Next.js page; the RSC payload is captured but the interactive bits
   (collapsible sections, code copy buttons) may not work.

6. **WebSocket (`_ws/`)** — the live site used a WS connection (likely for
   real-time tier updates). Empty in the capture. No WS server here.

7. **Mode-specific pages** (`/rankings/sword`, `/rankings/pot`, etc.) — all
   served from the same `rankings/overall.html`. The client JS switches tabs
   via the nav; direct deep links to per-mode pages work because the JS reads
   the URL path on load.

8. **`/rankings/spear`** — spear was a newer mode; some RSC payload files
   are captured for it but the ranking data (no `/api/v2/mode/spear` endpoint
   data in the HAR) means the tab will show an empty list.

## Reverse proxy (Nginx, optional)

```nginx
server {
    listen 80;
    server_name yourdomain.com;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
    }
}
```

Then run with `PORT=3000 node server.js` (or use pm2/systemd).
