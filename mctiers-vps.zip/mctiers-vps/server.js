// mctiers-vps/server.js
// Node.js 18+ — no deps beyond built-ins
// Serves: all static captured assets + mock API for /api/v2/

import http from 'http';
import fs from 'fs';
import path from 'path';
import url from 'url';

const __dirname = path.dirname(url.fileURLToPath(import.meta.url));
const PORT = process.env.PORT || 3000;
const PUBLIC = path.join(__dirname, 'public');
const DATA = path.join(__dirname, 'data');

// ─── MIME MAP ────────────────────────────────────────────────────────────────
const MIME = {
  '.html': 'text/html; charset=utf-8',
  '.js':   'application/javascript',
  '.css':  'text/css',
  '.json': 'application/json',
  '.svg':  'image/svg+xml',
  '.png':  'image/png',
  '.webp': 'image/webp',
  '.woff2':'font/woff2',
  '.txt':  'text/plain',
};

// ─── DATA LOADING ─────────────────────────────────────────────────────────────
let modeList = {};
let overallAll = [];

function loadData() {
  try {
    modeList = JSON.parse(fs.readFileSync(path.join(DATA, 'mode_list.json'), 'utf-8'));
    overallAll = JSON.parse(fs.readFileSync(path.join(DATA, 'overall_all.json'), 'utf-8'));
    console.log(`[data] loaded ${overallAll.length} players, ${Object.keys(modeList).length} modes`);
  } catch (e) {
    console.error('[data] failed to load:', e.message);
  }
}
loadData();

// ─── ROUTE HELPERS ────────────────────────────────────────────────────────────
function json(res, data, status = 200) {
  const body = JSON.stringify(data);
  res.writeHead(status, {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Content-Length': Buffer.byteLength(body),
  });
  res.end(body);
}

function serveFile(res, filepath) {
  let stat;
  try {
    stat = fs.statSync(filepath);
  } catch {
    return false;
  }
  if (!stat.isFile()) return false;
  const ext = path.extname(filepath).toLowerCase();
  const mime = MIME[ext] || 'application/octet-stream';
  res.writeHead(200, {
    'Content-Type': mime,
    'Content-Length': stat.size,
    'Cache-Control': ext === '.html' ? 'no-cache' : 'public, max-age=31536000',
  });
  fs.createReadStream(filepath).pipe(res);
  return true;
}

function redirect(res, to) {
  res.writeHead(307, { Location: to });
  res.end();
}

// ─── API HANDLERS ─────────────────────────────────────────────────────────────
function handleAPI(req, res, pathname, query) {
  // GET /api/v2/mode/list
  if (pathname === '/api/v2/mode/list') {
    return json(res, modeList);
  }

  // GET /api/v2/mode/:mode  (paginated with ?from=&count=)
  const modeMatch = pathname.match(/^\/api\/v2\/mode\/([a-z]+)$/);
  if (modeMatch) {
    const mode = modeMatch[1];
    const from  = parseInt(query.from  ?? '0',  10);
    const count = parseInt(query.count ?? '10', 10);

    if (mode === 'overall') {
      const slice = overallAll.slice(from, from + count);
      return json(res, slice);
    }

    // per-mode: filter players that have a ranking in this mode
    const filtered = overallAll
      .filter(p => p.rankings && p.rankings[mode])
      .sort((a, b) => {
        const ta = a.rankings[mode].tier * 10 + a.rankings[mode].pos;
        const tb = b.rankings[mode].tier * 10 + b.rankings[mode].pos;
        return ta - tb;
      });

    const slice = filtered.slice(from, from + count);
    return json(res, slice);
  }

  // GET /api/v2/player/:name
  const playerMatch = pathname.match(/^\/api\/v2\/player\/(.+)$/);
  if (playerMatch) {
    const name = decodeURIComponent(playerMatch[1]).toLowerCase();
    const player = overallAll.find(p => p.name.toLowerCase() === name);
    if (player) return json(res, player);
    return json(res, { error: 'Player not found' }, 404);
  }

  return json(res, { error: 'Not found' }, 404);
}

// ─── MAIN REQUEST HANDLER ─────────────────────────────────────────────────────
function handler(req, res) {
  const parsed = new URL(req.url, `http://localhost`);
  const pathname = parsed.pathname;
  const query = Object.fromEntries(parsed.searchParams);

  // CORS preflight
  if (req.method === 'OPTIONS') {
    res.writeHead(204, { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'GET' });
    return res.end();
  }

  // API routes
  if (pathname.startsWith('/api/')) {
    return handleAPI(req, res, pathname, query);
  }

  // Root → redirect to /rankings/overall
  if (pathname === '/') {
    return redirect(res, '/rankings/overall');
  }

  // /rankings → /rankings/overall
  if (pathname === '/rankings' || pathname === '/rankings/') {
    return redirect(res, '/rankings/overall');
  }

  // Try exact file match
  let filepath = path.join(PUBLIC, pathname);
  if (serveFile(res, filepath)) return;

  // Try .html extension
  if (!path.extname(pathname)) {
    if (serveFile(res, filepath + '.html')) return;
    // try index.html inside dir
    if (serveFile(res, path.join(filepath, 'index.html'))) return;
  }

  // /rankings/overall, /rankings/sword, etc. → serve rankings.html
  if (pathname.startsWith('/rankings/')) {
    if (serveFile(res, path.join(PUBLIC, 'rankings', 'overall.html'))) return;
    if (serveFile(res, path.join(PUBLIC, 'rankings.html'))) return;
  }

  // Mode pages (legacy /overall, /sword, etc.)
  const modeNames = ['overall','vanilla','uhc','pot','nethop','smp','sword','axe','mace','spear'];
  const seg = pathname.replace(/^\//, '').split('/')[0];
  if (modeNames.includes(seg)) {
    if (serveFile(res, path.join(PUBLIC, 'rankings', 'overall.html'))) return;
  }

  // 404
  res.writeHead(404, { 'Content-Type': 'text/plain' });
  res.end(`404 – ${pathname} not found`);
}

// ─── START ────────────────────────────────────────────────────────────────────
const server = http.createServer(handler);
server.listen(PORT, () => {
  console.log(`mctiers running on http://localhost:${PORT}`);
});
